package com.speech.byteplus;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.speech.protocol.EventType;
import com.speech.protocol.Message;
import com.speech.protocol.MsgType;
import com.speech.protocol.SpeechWebSocketClient;
import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 播客(Podcast)语音合成演示类
 * <p>
 * 设计目的：
 * 1. 验证BytePlus Podcast TTS WebSocket接口的调用流程。
 * 2. 展示如何处理多轮对话(Round)的音频拼接与保存。
 * 3. 提供断连重试机制的参考实现。
 * <p>
 * 实现思路：
 * - 使用WebSocket建立长连接。
 * - 构造包含文本、场景、音频配置的请求Payload。
 * - 通过事件循环处理服务端返回的音频流(AUDIO_ONLY_SERVER)和控制指令(FULL_SERVER_RESPONSE)。
 * - 针对Podcast场景特有的Round事件进行音频分段与合并。
 */
@Slf4j
public class Podcasts {
    //    private static final String ENDPOINT = "wss://voice.ap-southeast-1.bytepluses.com/api/v3/sami/podcasttts";
    private static final String ENDPOINT = "wss://openspeech.bytedance.com/api/v3/sami/podcasttts";
    private static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 获取资源ID
     * <p>
     * 实现逻辑：
     * 1. 返回固定的资源ID字符串，用于标识服务类型。
     *
     * @return 对应的资源ID
     */
    public static String resourceId() {
        return "volc.service_type.10050";
    }

    /**
     * 程序入口
     * <p>
     * 实现逻辑：
     * 1. 初始化配置参数（AppId, Token等）。
     * 2. 构建鉴权Header。
     * 3. 建立WebSocket连接并发送指令。
     * 4. 处理音频流与事件响应。
     * 5. 支持断线重试与音频文件保存。
     *
     * @param args 命令行参数
     * @throws Exception 处理过程中的异常
     */
    public static void main(String[] args) throws Exception {
        // 实现思路：
        // 1. 优先读取系统属性配置，方便外部注入。
        // 2. 采用同步阻塞方式连接WebSocket。
        // 3. 构造请求参数，包含断点续传所需的retry_info。
        // 4. 持续读取消息直到SESSION_FINISHED或发生异常。

        // 配置参数
        String appId = System.getProperty("appId", "5164182866");
        String accessToken = System.getProperty("accessToken", "DP_oIhkq9Iu0YWB4zDZuhLH2tgp0Zw-J");

        // 读取输入文本
        // 实现思路：
        // 1. 默认初始化为系统属性或硬编码文本，作为兜底方案。
        // 2. 检查当前目录下是否存在 request.txt 文件。
        // 3. 若存在，读取全量内容覆盖默认文本，实现配置外置。
        String text = System.getProperty("text", "通用AI Agent或迎来冷却时刻");
        File requestFile = new File("request.txt");
        if (requestFile.exists() && requestFile.isFile()) {
            try {
                text = new String(Files.readAllBytes(requestFile.toPath()), StandardCharsets.UTF_8);
                log.info("已加载本地请求文件|Loaded_local_request_file,path={},text={}", requestFile.getAbsolutePath(), text);
            } catch (Exception e) {
                log.warn("读取本地文件失败_使用默认文本|Read_local_file_failed_using_default,error={}", e.getMessage());
            }
        }

        String encoding = System.getProperty("encoding", "mp3");
        String inputId = System.getProperty("input_id", "test_podcast");
        String scene = System.getProperty("scene", "deep_research");
        boolean useHeadMusic = Boolean.parseBoolean(System.getProperty("use_head_music", "true"));

        if (appId == null || accessToken == null) {
            log.error("Please set appId and accessToken system properties");
            System.exit(1);
        }

        // 设置请求头
//        Map<String, String> headers = new HashMap<>();
//        headers.put("X-Api-App-Key", appId);
//        headers.put("X-Api-Access-Key", accessToken);
//        headers.put("X-Api-Resource-Id", resourceId());
//        headers.put("X-Api-Connect-Id", UUID.randomUUID().toString());
        // 设置请求头
        Map<String, String> headers = new HashMap<>();
        // 1. App-Id 填您的应用ID变量
        headers.put("X-Api-App-Id", appId);
        // 2. App-Key 必须填这个固定的字符串，不能改
        headers.put("X-Api-App-Key", "aGjiRDfUWi");
        // 3. Access-Key 填您的 Token
        headers.put("X-Api-Access-Key", accessToken);
        // 4. Resource-Id: 资源ID
        headers.put("X-Api-Resource-Id", resourceId());
        headers.put("X-Api-Connect-Id", UUID.randomUUID().toString());

        boolean isPodcastRoundEnd = true;
        int lastRoundId = -1;
        String taskId = "";
        int retryNum = 5;

        SpeechWebSocketClient client = null;
        byte[] podcastAudio = new byte[0];

        try {
            while (retryNum > 0) {
                // 创建WebSocket客户端
                client = new SpeechWebSocketClient(new URI(ENDPOINT), headers);
                client.connectBlocking();

                // 准备请求参数
                Map<String, Object> request = new HashMap<>();
                request.put("req_params", Map.of(
                        "input_id", inputId,
                        "input_text", text,
                        "action", 0,
                        "scene", scene,
                        "use_head_music", useHeadMusic,
                        "audio_config", Map.of(
                                "format", encoding,
                                "sample_rate", 24000,
                                "speech_rate", 0
                        )
                ));

                // 如果连接中途断开，需要利用retry_info进行重试
                if (!isPodcastRoundEnd) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> reqParams = new HashMap<>((Map<String, Object>) request.get("req_params"));
                    reqParams.put("retry_info", Map.of(
                            "retry_task_id", taskId,
                            "last_finished_round_id", lastRoundId
                    ));
                    request.put("req_params", reqParams);
                }

                log.info("request: {}", objectMapper.writeValueAsString(request));

                // 发送开始连接指令
                client.sendStartConnection();

                // 处理每个句子
                boolean audioReceived = false;

                String sessionId = UUID.randomUUID().toString();
                if (taskId.isEmpty()) {
                    taskId = sessionId;
                }

                byte[] audio = new byte[0];

                // 发送开始会话指令
                client.sendStartSession(objectMapper.writeValueAsBytes(request.get("req_params")), sessionId);

                // 发送结束会话指令
                client.sendFinishSession(sessionId);

                String voice = "";
                int round = -10000;

                // 接收服务端响应
                while (true) {
                    Message msg = client.receiveMessage();

                    if (msg.getType() == MsgType.AUDIO_ONLY_SERVER && msg.getEvent() == EventType.PODCAST_ROUND_RESPONSE) {
                        if (!audioReceived && audio.length > 0) {
                            audioReceived = true;
                        }
                        byte[] newAudio = new byte[audio.length + msg.getPayload().length];
                        System.arraycopy(audio, 0, newAudio, 0, audio.length);
                        System.arraycopy(msg.getPayload(), 0, newAudio, audio.length, msg.getPayload().length);
                        audio = newAudio;
                    } else if (msg.getType() == MsgType.ERROR) {
                        throw new RuntimeException("Server returned error: " + new String(msg.getPayload()));
                    }

                    if (msg.getType() == MsgType.FULL_SERVER_RESPONSE && msg.getEvent() == EventType.PODCAST_ROUND_START) {
                        // 播客回合(Round)开始
                        String jsonString = new String(msg.getPayload(), StandardCharsets.UTF_8);
                        // 将JSON字符串转换为Map
                        @SuppressWarnings("unchecked")
                        Map<String, Object> map = objectMapper.readValue(jsonString, Map.class);
                        // 获取发音人(voice)和回合ID(round)
                        voice = (String) map.get("speaker");
                        round = (int) map.get("round_id");
                        if (round == -1) {
                            voice = "head_music";
                        }
                        isPodcastRoundEnd = false;

                        log.info("Starting new round: {}", jsonString);
                    }

                    if (msg.getType() == MsgType.FULL_SERVER_RESPONSE && msg.getEvent() == EventType.PODCAST_ROUND_END) {
                        isPodcastRoundEnd = true;
                        lastRoundId = round;
                        // 播客回合音频结束
                        //// 这里的 if (audio.length > 0) {...} 代码块原本负责保存每一句话的音频
                        //    // 我们把它全部注释掉，这样就不会生成中间文件了
//                        if (audio.length > 0) {
//                            String fileName = String.format("%s_%d.%s", voice, round, encoding);
//                            Files.write(new File(fileName).toPath(), audio);
//                            log.info("Audio saved to file: {}", fileName);
//                        }
                        // 合并最终音频
                        byte[] newAudio = new byte[podcastAudio.length + audio.length];
                        System.arraycopy(podcastAudio, 0, newAudio, 0, podcastAudio.length);
                        System.arraycopy(audio, 0, newAudio, podcastAudio.length, audio.length);
                        podcastAudio = newAudio;
                        audio = new byte[0];
                        continue;
                    }

                    if (msg.getEvent() == EventType.SESSION_FINISHED) {
                        break;
                    }
                }

                if (!audioReceived) {
                    throw new RuntimeException("No audio data received");
                }

                client.sendFinishConnection();

                // 所有音频接收完毕
                if (isPodcastRoundEnd && podcastAudio.length > 0) {
                    // 构造带时间戳的文件名，格式为 yyyy-MM-dd_HHmmss，以避免在文件名中使用空格或冒号
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd_HHmmss");
                    String timestamp = LocalDateTime.now().format(formatter);
                    String fileName = String.format("podcast_%s.%s", timestamp, encoding);

                    // 将最终音频文件保存到与 request.txt 同级的当前目录下
                    File outputFile = new File(fileName);
                    Files.write(outputFile.toPath(), podcastAudio);
                    log.info("最终播客音频已保存|Final_podcast_audio_saved,path={}", outputFile.getAbsolutePath());
                    break;
                }

                if (!isPodcastRoundEnd) {
                    retryNum -= 1;
                    log.info("Current podcast not finished, resuming from round {}", lastRoundId);
                    Thread.sleep(1000);
                }
            }
        } finally {
            // 结束连接
            if (client != null) {
                client.closeBlocking();
            }
        }
    }
} 